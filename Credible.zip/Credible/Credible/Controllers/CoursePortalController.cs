﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Credible.Models;

namespace Credible.Controllers
{
    public class CoursePortalController : Controller
	{
		private ICoursePortalRepository repository;

		public CoursePortalController(ICoursePortalRepository repo)
		{
			repository = repo;
		}

		public ViewResult List() => View(repository.CoursePortals);

		public ViewResult GetCourses(int id)
		{
			var course = repository.CoursePortals
				.Where(i => i.PortalID == id);

			return View(course);
		}
	}
}
