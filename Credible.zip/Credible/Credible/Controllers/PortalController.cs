﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Credible.Models;

namespace Credible.Controllers
{
    public class PortalController : Controller
    {
		private IPortalRepository repository;

		public PortalController(IPortalRepository repo)
		{
			repository = repo;
		}

		public ViewResult List() => View(repository.Portals);
    }
}
