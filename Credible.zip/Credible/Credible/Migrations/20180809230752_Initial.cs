﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace Credible.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Portals",
                columns: table => new
                {
                    PortalID = table.Column<int>(nullable: false),
                    PortalName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Portals", x => x.PortalID);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    UserID = table.Column<int>(nullable: false),
                    FirstNm = table.Column<string>(nullable: true),
                    LastNm = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.UserID);
                });

            migrationBuilder.CreateTable(
                name: "CoursePortals",
                columns: table => new
                {
                    CoursePortalID = table.Column<int>(nullable: false),
                    CoursePortalName = table.Column<string>(nullable: true),
                    PortalID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CoursePortals", x => x.CoursePortalID);
                    table.ForeignKey(
                        name: "FK_CoursePortals_Portals_PortalID",
                        column: x => x.PortalID,
                        principalTable: "Portals",
                        principalColumn: "PortalID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Registrations",
                columns: table => new
                {
                    RegistrationID = table.Column<int>(nullable: false),
                    CoursePortalID = table.Column<int>(nullable: false),
                    RegistrationDTTM = table.Column<DateTime>(nullable: false),
                    UserID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Registrations", x => x.RegistrationID);
                    table.ForeignKey(
                        name: "FK_Registrations_CoursePortals_CoursePortalID",
                        column: x => x.CoursePortalID,
                        principalTable: "CoursePortals",
                        principalColumn: "CoursePortalID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Registrations_Users_UserID",
                        column: x => x.UserID,
                        principalTable: "Users",
                        principalColumn: "UserID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_CoursePortals_PortalID",
                table: "CoursePortals",
                column: "PortalID");

            migrationBuilder.CreateIndex(
                name: "IX_Registrations_CoursePortalID",
                table: "Registrations",
                column: "CoursePortalID");

            migrationBuilder.CreateIndex(
                name: "IX_Registrations_UserID",
                table: "Registrations",
                column: "UserID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Registrations");

            migrationBuilder.DropTable(
                name: "CoursePortals");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Portals");
        }
    }
}
