﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Credible.Models
{
    public class EFCoursePortalRepository : ICoursePortalRepository
    {
		private ApplicationDbContext context;

		public EFCoursePortalRepository(ApplicationDbContext ctx)
		{
			context = ctx;
		}

		public IQueryable<CoursePortal> CoursePortals => context.CoursePortals;

	}
}
