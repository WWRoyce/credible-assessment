﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Credible.Models
{
    public class User
	{
		public int UserID { get; set; }
		public string FirstNm { get; set; }
		public string LastNm { get; set; }

		public ICollection<Registration> Registrations { get; set; }
	}
}
