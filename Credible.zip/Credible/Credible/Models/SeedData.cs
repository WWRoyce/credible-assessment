﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;

namespace Credible.Models
{
	public class SeedData
	{
		public static void EnsurePopulated(IApplicationBuilder app)
		{
			ApplicationDbContext context = app.ApplicationServices.GetRequiredService<ApplicationDbContext>();

			if (!context.Portals.Any())
			{
				context.Portals.AddRange(
					new Portal { PortalName = "Test Client One" },
					new Portal { PortalName = "Test Client Two" },
					new Portal { PortalName = "Test Client Three" },
					new Portal { PortalName = "Test Client Four" },
					new Portal { PortalName = "Test Client Five" },
					new Portal { PortalName = "Test Client Six" },
					new Portal { PortalName = "Test Client Seven" },
					new Portal { PortalName = "Test Client Eight" },
					new Portal { PortalName = "Test Client Nine" },
					new Portal { PortalName = "Test Client Ten" }
					);

				context.SaveChanges();
			}

			if (!context.CoursePortals.Any())
			{
				context.CoursePortals.AddRange(
					new CoursePortal { CoursePortalName = "Course1", PortalID = 10 },
					new CoursePortal { CoursePortalName = "Course2", PortalID = 9 },
					new CoursePortal { CoursePortalName = "Course3", PortalID = 8 },
					new CoursePortal { CoursePortalName = "Course4", PortalID = 7 },
					new CoursePortal { CoursePortalName = "Course5", PortalID = 6 },
					new CoursePortal { CoursePortalName = "Course6", PortalID = 5 },
					new CoursePortal { CoursePortalName = "Course7", PortalID = 4 },
					new CoursePortal { CoursePortalName = "Course8", PortalID = 3 },
					new CoursePortal { CoursePortalName = "Course9", PortalID = 2 },
					new CoursePortal { CoursePortalName = "Course10", PortalID = 1 },
					new CoursePortal { CoursePortalName = "Course11", PortalID = 10 },
					new CoursePortal { CoursePortalName = "Course12", PortalID = 9 },
					new CoursePortal { CoursePortalName = "Course13", PortalID = 8 },
					new CoursePortal { CoursePortalName = "Course14", PortalID = 7 },
					new CoursePortal { CoursePortalName = "Course15", PortalID = 6 },
					new CoursePortal { CoursePortalName = "Course16", PortalID = 5 },
					new CoursePortal { CoursePortalName = "Course17", PortalID = 4 },
					new CoursePortal { CoursePortalName = "Course18", PortalID = 3 },
					new CoursePortal { CoursePortalName = "Course19", PortalID = 2 },
					new CoursePortal { CoursePortalName = "Course20", PortalID = 1 },
					new CoursePortal { CoursePortalName = "Course21", PortalID = 10 },
					new CoursePortal { CoursePortalName = "Course22", PortalID = 8 },
					new CoursePortal { CoursePortalName = "Course23", PortalID = 8 },
					new CoursePortal { CoursePortalName = "Course24", PortalID = 7 },
					new CoursePortal { CoursePortalName = "Course25", PortalID = 6 },
					new CoursePortal { CoursePortalName = "Course26", PortalID = 5 },
					new CoursePortal { CoursePortalName = "Course27", PortalID = 4 },
					new CoursePortal { CoursePortalName = "Course28", PortalID = 3 },
					new CoursePortal { CoursePortalName = "Course29", PortalID = 2 },
					new CoursePortal { CoursePortalName = "Course30", PortalID = 1 }
					);

				context.SaveChanges();
			}

			if (!context.Users.Any())
			{
				context.Users.AddRange(
					new User { FirstNm = "Joe", LastNm = "Smith" },
					new User { FirstNm = "Betty", LastNm = "Cooper" },
					new User { FirstNm = "Veronica", LastNm = "Lodge" },
					new User { FirstNm = "Reggie", LastNm = "Mantle" },
					new User { FirstNm = "Moose", LastNm = "Johnson" },
					new User { FirstNm = "Chandler", LastNm = "Bing" },
					new User { FirstNm = "Ross", LastNm = "Geller" },
					new User { FirstNm = "Monica", LastNm = "Geller" },
					new User { FirstNm = "Phoebe", LastNm = "Buffay" },
					new User { FirstNm = "John", LastNm = "Smith" },
					new User { FirstNm = "Alice", LastNm = "Jones" },
					new User { FirstNm = "Chip", LastNm = "Parker" },
					new User { FirstNm = "Sally", LastNm = "Parker" },
					new User { FirstNm = "Steve", LastNm = "Perry" },
					new User { FirstNm = "Neil", LastNm = "Schon" },
					new User { FirstNm = "Ainsley", LastNm = "Dunbar" },
					new User { FirstNm = "Michael", LastNm = "Sieber" },
					new User { FirstNm = "Guy", LastNm = "Wethers" },
					new User { FirstNm = "James", LastNm = "Almerico" },
					new User { FirstNm = "Brian", LastNm = "Johnson" },
					new User { FirstNm = "Matt", LastNm = "Dean" },
					new User { FirstNm = "Rhonda", LastNm = "Rowdy" },
					new User { FirstNm = "Hulk", LastNm = "Hogan" },
					new User { FirstNm = "Joe", LastNm = "Cooper" },
					new User { FirstNm = "Bob", LastNm = "Jones" }
					);
				context.SaveChanges();
			}

			if (!context.Registrations.Any())
			{
				context.Registrations.AddRange(
					new Registration { CoursePortalID = 12, RegistrationDTTM = DateTime.Parse("1/3/2018"), UserID = 10 },
					new Registration { CoursePortalID = 10, RegistrationDTTM = DateTime.Parse("11/8/2018"), UserID = 11 },
					new Registration { CoursePortalID = 18, RegistrationDTTM = DateTime.Parse("12/3/2018"), UserID = 12 },
					new Registration { CoursePortalID = 17, RegistrationDTTM = DateTime.Parse("1/31/2018"), UserID = 14 },
					new Registration { CoursePortalID = 16, RegistrationDTTM = DateTime.Parse("10/3/2018"), UserID = 16 },
					new Registration { CoursePortalID = 16, RegistrationDTTM = DateTime.Parse("10/3/2018"), UserID = 17 },
					new Registration { CoursePortalID = 11, RegistrationDTTM = DateTime.Parse("1/3/2018"), UserID = 10 },
					new Registration { CoursePortalID = 13, RegistrationDTTM = DateTime.Parse("11/8/2018"), UserID = 11 },
					new Registration { CoursePortalID = 14, RegistrationDTTM = DateTime.Parse("12/3/2018"), UserID = 12 },
					new Registration { CoursePortalID = 15, RegistrationDTTM = DateTime.Parse("1/31/2018"), UserID = 14 },
					new Registration { CoursePortalID = 16, RegistrationDTTM = DateTime.Parse("10/3/2018"), UserID = 16 },
					new Registration { CoursePortalID = 16, RegistrationDTTM = DateTime.Parse("10/3/2018"), UserID = 17 },
					new Registration { CoursePortalID = 19, RegistrationDTTM = DateTime.Parse("4/13/2018"), UserID = 18 }
					);
				context.SaveChanges();
			}
		}
	}
}
