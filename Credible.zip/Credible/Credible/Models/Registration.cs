﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Credible.Models
{
    public class Registration
	{
		public int RegistrationID { get; set; }
		public int CoursePortalID { get; set; }
		public int UserID { get; set; }
		public DateTime RegistrationDTTM { get; set; }

		public CoursePortal CoursePortal { get; set; }
		public User User { get; set; }
		
    }
}
