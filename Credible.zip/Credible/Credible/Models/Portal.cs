﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Credible.Models
{
    public class Portal
	{
		public int PortalID { get; set; }
		public string PortalName { get; set; }

		public virtual ICollection<CoursePortal> CoursePortals { get; set; }

	}
}
