﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Credible.Models
{
    public class CoursePortal
	{
		public int CoursePortalID { get; set; }
		public string CoursePortalName { get; set; }
		public int PortalID { get; set; }

		public virtual ICollection<Registration> Registrations { get; set; }
	}
}
