﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Credible.Models
{
    public class EFPortalRepository : IPortalRepository
    {
		private ApplicationDbContext context;

		public EFPortalRepository(ApplicationDbContext ctx)
		{
			context = ctx;
		}

		public IQueryable<Portal> Portals => context.Portals;
    }
}
