SET IDENTITY_INSERT [dbo].[Portals] ON
INSERT INTO [dbo].[Portals] ([PortalID], [PortalName]) VALUES (1, N'Test Client One')
INSERT INTO [dbo].[Portals] ([PortalID], [PortalName]) VALUES (2, N'Test Client Two')
INSERT INTO [dbo].[Portals] ([PortalID], [PortalName]) VALUES (3, N'Test Client Three')
INSERT INTO [dbo].[Portals] ([PortalID], [PortalName]) VALUES (4, N'Test Client Four')
INSERT INTO [dbo].[Portals] ([PortalID], [PortalName]) VALUES (5, N'Test Client Five')
INSERT INTO [dbo].[Portals] ([PortalID], [PortalName]) VALUES (6, N'Test Client Six')
INSERT INTO [dbo].[Portals] ([PortalID], [PortalName]) VALUES (7, N'Test Client Seven')
INSERT INTO [dbo].[Portals] ([PortalID], [PortalName]) VALUES (8, N'Test Client Eight')
INSERT INTO [dbo].[Portals] ([PortalID], [PortalName]) VALUES (9, N'Test Client Nine')
INSERT INTO [dbo].[Portals] ([PortalID], [PortalName]) VALUES (10, N'Test Client Ten')
SET IDENTITY_INSERT [dbo].[Portals] OFF
